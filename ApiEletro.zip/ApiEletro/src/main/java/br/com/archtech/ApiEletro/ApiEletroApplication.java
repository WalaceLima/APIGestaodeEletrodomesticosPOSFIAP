package br.com.archtech.ApiEletro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEletroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEletroApplication.class, args);
	}

}
